import numpy as np
import cv2
import os
import pickle
from imutils import paths
from imutils import build_montages
from skimage import feature
from sklearn.metrics import confusion_matrix
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier


def quantify_image(image):
    features=feature.hog(image,orientations=9,pixels_per_cell=(10,10), cells_per_block=(2,2),transform_sqrt=True, block_norm="L1")
    return features

def load_split(path):
    imagePaths=list(paths.list_images(path))
    data=[]
    labels=[]
    
    for  imagePath in imagePaths:
        label=imagePath.split(os.path.sep)[-2]
        
        image=cv2.imread(imagePath)
        image=cv2.cvtColor(image,cv2.COLOR_BGR2GRAY)
        image=cv2.resize(image,(200,200))
        
        image=cv2.threshold(image,0,255,cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)[1]
        features=quantify_image (image)
        
        data.append(features)
        labels.append(label)
    return (np.array(data),np.array(labels))

trainingpath=r"..\dataset\spiral\training"
testingpath=r"..\dataset\spiral\testing"
print("[INFO] Loading data")
(x_train,y_train)=load_split(trainingpath)
(x_test,y_test)=load_split(testingpath)
        


le=LabelEncoder()

y_train=le.fit_transform(y_train)
y_test=le.transform(y_test)

print(x_train.shape,y_train.shape)

print("[info] training model")
model=RandomForestClassifier(n_estimators=100)
model.fit(x_train,y_train)

testingpaths=list(paths.list_images(testingpath))
idxs=np.arange(0,len(testingpaths))
idxs=np.random.choice(idxs,size=(25,), replace=False)
images=[]

for i in idxs:
    image=cv2.imread(testingpaths[i])
    output=image.copy()
    output=cv2.resize(output,(128,128))
    
    image=cv2.cvtColor(image,cv2.COLOR_BGR2GRAY)
    image=cv2.resize(image,(200,200))
    image=cv2.threshold(image,0,255,cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)[1]
    features=quantify_image(image)
    preds=model.predict([features])
    
    label=le.inverse_transform(preds)[0]
    color=(0,255,0) if label=="healthy" else (0,0,255)
    cv2.putText(output,label, (3,20),cv2.FONT_HERSHEY_SIMPLEX,0.5,color,2)
    images.append(output)
    
montage=build_montages(images,(128,128),(5,5))[0]
cv2.imshow("Output",montage)
cv2.waitKey(0)

predictions=model.predict(x_test)
cm=confusion_matrix(y_test, predictions).flatten()
print(cm)
(tp,fp,fn,tn)=cm
accuracy=(tp+tn)/float(cm.sum())
print(accuracy)

pickle.dump(model,open('parkinson.pkl','wb'))

