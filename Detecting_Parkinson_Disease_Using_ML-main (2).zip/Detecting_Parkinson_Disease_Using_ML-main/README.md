# Detecting_Parkinson_Disease_Using_ML
Dataset link:https://drive.google.com/drive/folders/1Y3m9E98m33v6L9AqWWgHlzvMA_TsyQBi?usp=sharing
